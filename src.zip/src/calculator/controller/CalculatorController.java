/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculator.controller;
import calculator.exception.InvalidInputException;
import calculator.exception.NotEnoughElementException;
import calculator.model.*;
import calculator.view.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.beans.binding.Bindings;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
/**
 *
 * @author Carlo Marna
 */
public class CalculatorController {
    private CalculatorModel model;
    private CalculatorView view;

    public CalculatorController(CalculatorModel model, CalculatorView view) {
        this.model = model;
        this.view = view;
        initButtons();
        initBindings();
    }
    
    private void initButtons(){
        for(int i = 0; i < 5; i++){
            view.numKeyboard.numop[i].setOnAction(e -> buttonPressedAction(e));
        }
        view.numKeyboard.numop[5].setOnAction(e -> buttonPressedDisplay(e));
        view.numKeyboard.numop[6].setOnAction(e -> buttonPressedAction(e));
        for(int i = 7; i < 27; i++){
            view.numKeyboard.numop[i].setOnAction(e -> buttonPressedDisplay(e));
        }
        view.numKeyboard.numop[27].setOnAction(e -> buttonPressedAction(e));
        for(int i = 0; i < 26 ; i++){
            view.letKeyboard.letters[i].setOnAction(e -> buttonPressedDisplay(e));
        }
    }
     
    private void buttonPressedDisplay(ActionEvent e){
        Button b = (Button) e.getSource();
        view.display.setText(view.display.getText()+b.getText());
    }
    
     private void buttonPressedAction(ActionEvent e){
        Button b = (Button) e.getSource();
        System.out.println(b.getText());
        try{
            String value = b.getText();
            System.out.println(value);
        switch(value){
            case "C":
                 view.display.setText("");
                 break;
            case "MC":
                model.clear();
                break;
            case "MO":
                model.over();
                break;
            case "MS":
                model.swap();
                break;
            case "MD":
                model.drop();
                break;
            case "MU":
                model.dup();
                break;
            case "EXE":
                veryfyInput(view.display.getText());
                break;
        }}catch (RuntimeException ex){
                view.display.setText(ex.getMessage());
                
                for(int i = 0; i < view.numKeyboard.ELEMENTS; i++)
                    if(i!=4)
                        view.numKeyboard.numop[i].disableProperty().bind(Bindings.equal(ex.getMessage(), view.display.textProperty()));
                
                 for(int i = 0; i < view.letKeyboard.CHARACTERS; i++)
                        view.letKeyboard.letters[i].disableProperty().bind(Bindings.equal(ex.getMessage(), view.display.textProperty()));
                
            }finally{
         view.memory.setText(model.getSf().stampaDodiceElementi());
           }
            
        }
     
        void veryfyInput(String input) throws RuntimeException{        
            String regex = "([+-]?\\d*\\.?\\d+)?([+-]?\\d*\\.?\\d+)?j?";
            String value = view.display.getText();
            view.display.setText("");
            if(value.matches(regex)){
                Pattern pattern = Pattern.compile(regex);
                Matcher matcher = pattern.matcher(input);
                if (matcher.matches()) {
                    String realPart = matcher.group(1);
                    String imagPart = matcher.group(2);
                    double real = (realPart != null && !realPart.isEmpty()) ? Double.parseDouble(realPart) : 0.0;
                    double imag = (imagPart != null && !imagPart.isEmpty()) ? Double.parseDouble(imagPart) : 0.0;
                    model.getSf().push(new Complex(real,imag));     
                }
            }else if (value.matches("[-+*÷√]")){
                    switch(value){
                        case "÷":
                            model.rapporto();
                            break;
                        case "-":
                            model.differenza();
                            break;
                        case "+":
                            model.somma();
                            break;
                        case "√":
                            model.radice();
                            break;
                        case "+/-":
                            model.cambioSegno();
                            break;
                    }
            }else if (value.matches("[-+<>]x[a-z]")){
                String primaParte = value.substring(0, 2);
                char secondaParte = value.charAt(2);
                switch (primaParte){
                    case("<x"):
                        model.duplicazioneVariabile(secondaParte);
                    case(">x"):
                        model.assegnaVaribile(secondaParte);
                        break;
                    case("+x"):
                        model.sommaVariabile(secondaParte);
                        break;
                    case("-x"):
                        model.differenzaVariabile(secondaParte);
                        break;                   
                }
                
            }else{
                throw new InvalidInputException("Input non valido");
            }
            view.memory.setText(model.getSf().stampaDodiceElementi());
        }
     
   
    private void initBindings(){
        for(int i = 0; i < 4; i++)
            view.numKeyboard.numop[i].disableProperty().bind(Bindings.notEqual("", view.display.textProperty()));
        view.numKeyboard.numop[6].disableProperty().bind(Bindings.notEqual("", view.display.textProperty()));
        view.numKeyboard.numop[27].disableProperty().bind(Bindings.equal("", view.display.textProperty()));
        view.numKeyboard.numop[4].disableProperty().bind(Bindings.equal("", view.display.textProperty()));
        
        
        
    }
    
}
