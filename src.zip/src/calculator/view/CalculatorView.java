/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculator.view;

import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Border;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 *
 * @author Carlo Marna
 */
public class CalculatorView extends VBox{
    public LettersKeyboard letKeyboard;
    public NumbersKeyboard numKeyboard;
    public Label display;
    public Label textMemory;
    public TextArea memory;
    public CalculatorView() {
        super();
        this.setAlignment(Pos.CENTER);
        this.setSpacing(20);
        display = new Label();
        display.setText("");
        display.setStyle("-fx-border-color: black;");
        //display.applyCss();
        
        memory = new TextArea();
        memory.setEditable(false);
        memory.setPrefHeight(20);
        memory.setPrefWidth(10);
            
        textMemory = new Label();
        textMemory.setText("Memory");

        this.getChildren().add(display);
        
        HBox body = new HBox();
        VBox tasti = new VBox();
        
        letKeyboard = new LettersKeyboard();
        numKeyboard = new NumbersKeyboard();
        tasti.getChildren().add(numKeyboard);
        tasti.getChildren().add(letKeyboard);
        
        body.getChildren().addAll(textMemory, memory, tasti);
        body.setAlignment(Pos.CENTER);
        
        this.getChildren().add(body);
       
    }
}
