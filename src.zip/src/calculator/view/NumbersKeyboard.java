/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculator.view;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

/**
 *
 * @author Carlo Marna
 */
public class NumbersKeyboard extends VBox{
    public Button[] numop;

    public final int ELEMENTS = 28;
    public final int COLUMNS = 5;
    
    public NumbersKeyboard() {
        super();
        this.setAlignment(Pos.CENTER);
        this.setSpacing(20);
        intitButtons();
        placeButtons();
       
    }
    
    private void intitButtons(){
        numop = new Button[ELEMENTS];
        for(int i = 0; i < ELEMENTS; i++){
            numop[i] = new Button();}
        
        numop[0].setText("MO");
        numop[1].setText("MS");
        numop[2].setText("MD");
        numop[3].setText("MC");
        numop[4].setText("C");
        numop[5].setText(">x");
        numop[6].setText("MU");
        numop[7].setText("+/-");
        numop[8].setText("√");
        numop[9].setText("÷");
        numop[10].setText("<x");
        numop[11].setText("7");
        numop[12].setText("8");
        numop[13].setText("9");
        numop[14].setText("*");
        numop[15].setText("+x");
        numop[16].setText("4");
        numop[17].setText("5");
        numop[18].setText("6");
        numop[19].setText("-");
        numop[20].setText("-x");
        numop[21].setText("1");
        numop[22].setText("2");
        numop[23].setText("3");
        numop[24].setText("+");
        numop[25].setText(".");
        numop[26].setText("0");
        numop[27].setText("EXE");
    }
    
    
    private void placeButtons(){
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        for(int i = 0; i < ELEMENTS; i++){
            
            if(i == 26){
                System.out.println("Strunz");
                pane.add(numop[i], i%COLUMNS, i/COLUMNS, 3,1);}
            else
                pane.add(numop[i], i%COLUMNS, i/COLUMNS);
        }
        this.getChildren().add(pane);
       
    }
}
