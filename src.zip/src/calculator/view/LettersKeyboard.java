/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculator.view;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

/**
 *
 * @author Carlo Marna
 */
public class LettersKeyboard extends VBox{
    public Button[] letters;
    public final int CHARACTERS = 26;
    public final int COLUMNS = 7;
    
    
  public LettersKeyboard() {
        super();
        this.setAlignment(Pos.CENTER);
        this.setSpacing(20);
        intitButtons();
        placeButtons();
       
    }
    
    private void intitButtons(){
        letters = new Button[CHARACTERS];
        for (int i = 0; i < CHARACTERS; i++){
              letters[i] = new Button();
              letters[i].setText(Character.toString((char)(97+i)));
        }

    }
    
    
    private void placeButtons(){
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        for(int i = 0; i < CHARACTERS; i++){
            pane.add(letters[i], i%COLUMNS, i/COLUMNS);
        }
        this.getChildren().add(pane);
       
    }
}
