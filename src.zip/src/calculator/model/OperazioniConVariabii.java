/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package calculator.model;

/**
 *
 * @author Carlo Marna
 */
public interface OperazioniConVariabii {
    void sommaVariabile(char c);
    void differenzaVariabile(char c);
    void duplicazioneVariabile(char c);
    void assegnaVaribile(char c);
}
