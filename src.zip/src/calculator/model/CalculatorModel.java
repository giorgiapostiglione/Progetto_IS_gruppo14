/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculator.model;

import calculator.exception.*;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Carlo Marna
 */
public class CalculatorModel implements OperazioniAritmetiche, OperazioniConVariabii, OperazioniStrutturaDati {

    private StackFinito sf;
    private  Map <Character,Complex> variabili;
    
    public CalculatorModel() {
        sf = new StackFinito();
        variabili = new HashMap <>();
    }
    
    public StackFinito getSf(){
        return sf;
    }
    @Override
    public void somma() throws NotEnoughElementException{
        if(sf.getSize()<2)
            throw new NotEnoughElementException("Elementi insufficienti");
       sf.push(Complex.add(sf.pop(),sf.pop()));
        
    }

    @Override
    public void differenza() throws NotEnoughElementException{
        if(sf.getSize()<2)
            throw new NotEnoughElementException("Elementi insufficienti");
        sf.push(Complex.sub(sf.pop(),sf.pop()));
    }

    @Override
    public void prodotto() throws NotEnoughElementException{
         if(sf.getSize()<2)
            throw new NotEnoughElementException("Elementi insufficienti");
        sf.push(Complex.mul(sf.pop(),sf.pop()));
    }
    
   
    @Override
    public void rapporto() throws NotEnoughElementException, DivisionByZeroException{
         if(sf.getSize()<2)
            throw new NotEnoughElementException("Elementi insufficienti");
         else if (sf.viewElement(sf.getSize()-1).getIm()==0 && sf.viewElement(sf.getSize()-1).getRe()==0)   
            throw new DivisionByZeroException("Attenzione dividendo pari a zero");
        sf.push(Complex.div(sf.pop(),sf.pop()));    
    }

    @Override
    public void radice() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void cambioSegno() throws StackUnderflowException{
        if(sf.getSize()==0)
            throw new StackUnderflowException("Nessun elemento memorizzato");
        sf.push(Complex.change(sf.pop()));
    }

    @Override
    public void clear() {
        for(int i = 0; i < sf.getSize(); i++)
            sf.pop();
    }

    @Override
    public void swap() throws NotEnoughElementException{
      if(sf.getSize()<2)
            throw new NotEnoughElementException("Elementi insufficienti");
      Complex a = sf.pop();
      Complex b = sf.pop();
      sf.push(a);
      sf.push(b);
    }

    @Override
    public void drop() throws  StackUnderflowException{
       if(sf.getSize()==0)
           throw new StackUnderflowException("Nessun elemento memorizzato");
       sf.pop();
    }

    @Override
    public void dup()  throws StackUnderflowException,StackFullException {
       if(sf.getSize()==0)
           throw new StackUnderflowException("Nessun elemento memorizzato");
       else if (sf.getSize()==sf.getMaxSize())
           throw new StackFullException("Memoria piena");
       sf.push(sf.viewElement(sf.getSize()-1));
    }

    @Override
    public void over()  throws NotEnoughElementException, StackFullException {
        if(sf.getSize()<2)
           throw new StackUnderflowException("Nessun elemento memorizzato");
       else if (sf.getSize()==sf.getMaxSize())
           throw new StackFullException("Memoria piena");
       sf.push(sf.viewElement(sf.getSize()-2));
    }

    @Override
    public void sommaVariabile(char c) throws  InvalidInputException, StackUnderflowException {
        if(!variabili.containsKey(c))
            throw new InvalidInputException ("La variabile non esiste ");
        else if(sf.getSize()==0)
           throw new StackUnderflowException("Nessun elemento memorizzato");
        variabili.replace(c,Complex.add(sf.pop(), variabili.get(c))); 
        System.out.println(variabili);
    }

    @Override
    public void differenzaVariabile(char c) throws  InvalidInputException, StackUnderflowException {
      if(!variabili.containsKey(c))
            throw new InvalidInputException ("La variabile non esiste ");
        else   if(sf.getSize()==0)
           throw new StackUnderflowException("Nessun elemento memorizzato");
        variabili.replace(c,Complex.sub(sf.pop(), variabili.get(c)));
        System.out.println(variabili);
    }

    @Override
    public void duplicazioneVariabile(char c) throws  InvalidInputException,StackFullException {
       if(!variabili.containsKey(c))
            throw new InvalidInputException ("La variabile non esiste ");
       else if (sf.getSize()==sf.getMaxSize())
           throw new StackFullException("Memoria piena");
       sf.push(variabili.get(c));
    }

    @Override
    public void assegnaVaribile(char c) throws StackUnderflowException{
            if(sf.getSize()==0)
                 throw new StackUnderflowException("Not supported yet."); 
            if(variabili.containsKey(c))
                variabili.replace(c, sf.pop());
            else
                variabili.put(c, sf.pop());
            System.out.println(variabili);
    }
    
}
