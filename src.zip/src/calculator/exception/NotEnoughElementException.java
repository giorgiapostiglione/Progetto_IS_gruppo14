/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package calculator.exception;

/**
 *
 * @author Carlo Marna
 */
public class NotEnoughElementException extends RuntimeException{

    /**
     * Creates a new instance of <code>NotEnoughElementException</code> without
     * detail message.
     */
    public NotEnoughElementException() {
    }

    /**
     * Constructs an instance of <code>NotEnoughElementException</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public NotEnoughElementException(String msg) {
        super(msg);
    }
}
