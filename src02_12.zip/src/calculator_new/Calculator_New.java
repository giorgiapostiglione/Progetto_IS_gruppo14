/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package calculator_new;
import calculator.controller.CalculatorController;
import calculator.model.CalculatorModel;
import calculator.view.*;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author Carlo Marna
 */
public class Calculator_New extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        CalculatorView root = new CalculatorView();
        CalculatorModel model = new CalculatorModel();
        CalculatorController controller = new CalculatorController(model,root);
        Scene scene = new Scene(root, 650, 450);

 
        primaryStage.setTitle("C4LC0L4TR1C3");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
        
    }

   
    public static void main(String[] args) {
        launch(args);
    }
    
}
