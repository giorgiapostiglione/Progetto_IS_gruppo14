/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculator.view;


import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Border;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;

/**
 *
 * @author Carlo Marna
 */
public class CalculatorView extends VBox{
    
    public LettersKeyboard letKeyboard;
    public NumbersKeyboard numKeyboard;
    public Label display;
    public TextArea memory;
    public TextArea memoryVariable;
    
    public CalculatorView() {
        super();
        this.setAlignment(Pos.CENTER);
        this.setSpacing(5);
        
        letKeyboard = new LettersKeyboard();
        numKeyboard = new NumbersKeyboard();
        
        display = new Label();
        display.setText("");
        display.setPadding(new Insets(10));
        display.setStyle("-fx-border-color: black;");
        display.setPrefHeight(50);
        display.setPrefWidth(420);
        display.setFont((new Font(20))); 
        
        
        
        memory = new TextArea();
        memory.setEditable(false);
        memory.setPrefWidth(150);
        memory.setPrefHeight(320);
        memory.setFont((new Font(20))); 
        
        
        memoryVariable = new TextArea();
        memoryVariable.setEditable(false);
        memoryVariable.setPrefWidth(150);
        memoryVariable.setPrefHeight(320);
        memoryVariable.setFont((new Font(20))); 
            
        Label textMemory = new Label();
        textMemory.setText("Memory");
        textMemory.setStyle("-fx-font-weight: bold;");
        Label textVariable = new Label();
        textVariable.setText("Variables");
        textVariable.setStyle("-fx-font-weight: bold;");
        
        
        this.getChildren().addAll(display);
        
        HBox body = new HBox();
        
        VBox bodyL = new VBox();
        VBox tasti = new VBox();
        VBox bodyR = new VBox();
        
        VBox.setMargin(numKeyboard, new Insets(20,0,0,0));
        bodyL.setAlignment(Pos.CENTER);
        bodyR.setAlignment(Pos.CENTER);
        
        bodyL.getChildren().addAll(textMemory,memory);
        bodyR.getChildren().addAll(textVariable,memoryVariable);
        tasti.getChildren().addAll(numKeyboard,letKeyboard);
        
        body.setSpacing(15);
        tasti.setSpacing(5);

        body.getChildren().addAll(bodyL, tasti,bodyR);
        body.setAlignment(Pos.CENTER);
        this.getChildren().add(body);
       
    }
}
