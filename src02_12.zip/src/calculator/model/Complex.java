/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculator.model;

/**
 *
 * @author Carlo Marna
 */
public class Complex {
    private final double re;
    private final double im;

    public Complex(double re, double im) {
        this.re = re;
        this.im = im;
    }

    public double getRe() {
        return re;
    }

    public double getIm() {
        return im;
    }
    public String toString() {
        if (im == 0) return re + "\n";
        if (re == 0) return im + "j\n";
        if (im <  0) return re + " - " + (-im) + "j\n";
        return re + " + " + im + "j\n";
    }
    
   public static Complex add(Complex a, Complex b){

        double real = a.getRe() + b.getRe();
        double imag = a.getIm()+ b.getIm();
        return new Complex(real, imag);    
   } 
   
   public static Complex sub(Complex b, Complex a){
        double imag = a.getIm() - b.getIm();
        double real = a.getRe() - b.getRe();
        return new Complex(real, imag);    
   } 
   
   public static Complex mul(Complex a, Complex b){
        double real = a.getRe() * b.getRe() - a.getIm() * b.getIm();
        double imag = a.getRe()* b.getIm() + a.getIm() * b.getRe();
        return new Complex(real, imag);    
   }
   
   private static Complex reciproco(Complex b){
        double scale = b.getRe()*b.getRe() + b.getIm()*b.getIm();
        return new Complex(b.getRe() / scale, -b.getIm() / scale);
   }
   public static Complex div(Complex b, Complex a){
       return mul(a, reciproco(b));
   }
   
   public static Complex sqrt(Complex a, Complex b){
       
       return null;
   }
   
   public static Complex change(Complex a){
      return new Complex(-a.getRe(),-a.getIm());
   }
}
