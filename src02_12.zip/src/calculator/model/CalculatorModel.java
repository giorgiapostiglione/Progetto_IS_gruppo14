/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculator.model;

import calculator.exception.*;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author Carlo Marna
 */
public class CalculatorModel implements OperazioniAritmetiche, OperazioniConVariabii, OperazioniStrutturaDati {

    private StackFinito sf;
    private  Map <Character,Complex> variabili;
    
    public CalculatorModel() {
        sf = new StackFinito();
        variabili = new HashMap <>();
    }
    
    public StackFinito getSf(){
        return sf;
    }
    
    public String toStringHM(){
        StringBuffer sb = new StringBuffer();
        for(Map.Entry<Character, Complex> element : variabili.entrySet()){
            String s = element.getKey()+"="+element.getValue().toString();
            sb.append(s);
         }
        return sb.toString();
    }
    
    public void  insertNumber(double re, double im) throws StackFullException{
        sf.push(new Complex(re,im));
    }
    
    @Override
    public void somma() throws NotEnoughElementException{
        if(sf.getSize()<2)
            throw new NotEnoughElementException("Elementi insufficienti");
       sf.push(Complex.add(sf.pop(),sf.pop()));
        
    }

    @Override
    public void differenza() throws NotEnoughElementException{
        if(sf.getSize()<2)
            throw new NotEnoughElementException("Elementi insufficienti");
        sf.push(Complex.sub(sf.pop(),sf.pop()));
    }

    @Override
    public void prodotto() throws NotEnoughElementException{
         if(sf.getSize()<2)
            throw new NotEnoughElementException();
        sf.push(Complex.mul(sf.pop(),sf.pop()));
    }
    
    @Override
    public void rapporto() throws NotEnoughElementException, DivisionByZeroException{
         if(sf.getSize()<2)
            throw new NotEnoughElementException();
         else if (sf.viewElement(sf.getSize()-1).getIm()==0 && sf.viewElement(sf.getSize()-1).getRe()==0)   
            throw new DivisionByZeroException();
        sf.push(Complex.div(sf.pop(),sf.pop()));    
    }

    @Override
    public void radice() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void cambioSegno() throws StackUnderflowException{
        if(sf.getSize()==0)
            throw new StackUnderflowException();
        sf.push(Complex.change(sf.pop()));
    }

    @Override
    public void clear() {
        int dim = sf.getSize();
        for(int i = 0; i < dim; i++){
            sf.pop();}
    }

    @Override
    public void swap() throws NotEnoughElementException{
      if(sf.getSize()<2)
            throw new NotEnoughElementException();
      Complex a = sf.pop();
      Complex b = sf.pop();
      sf.push(a);
      sf.push(b);
    }

    @Override
    public void drop() throws  StackUnderflowException{
       if(sf.getSize()==0)
           throw new StackUnderflowException();
       sf.pop();
    }

    @Override
    public void dup()  throws StackUnderflowException,StackFullException {
       if(sf.getSize()==0)
           throw new StackUnderflowException("Nessun elemento memorizzato");
       else if (sf.getSize()==sf.getMaxSize())
           throw new StackFullException("Memoria piena");
       sf.push(sf.viewElement(sf.getSize()-1));
    }

    @Override
    public void over()  throws NotEnoughElementException, StackFullException {
        if(sf.getSize()<2)
           throw new NotEnoughElementException("Elementi insufficienti");
       else if (sf.getSize()==sf.getMaxSize())
           throw new StackFullException("Memoria piena");
       sf.push(sf.viewElement(sf.getSize()-2));
    }

    @Override
    public void sommaVariabile(char c) throws  InvalidInputException, StackUnderflowException {
        if(!variabili.containsKey(c))
            throw new InvalidVariableException ();
        else if(sf.getSize()==0)
           throw new StackUnderflowException();
        variabili.replace(c,Complex.add(sf.pop(), variabili.get(c))); 
    }

    @Override
    public void differenzaVariabile(char c) throws  InvalidInputException, StackUnderflowException {
      if(!variabili.containsKey(c))
            throw new InvalidVariableException ();
        else   if(sf.getSize()==0)
           throw new StackUnderflowException();
        variabili.replace(c,Complex.sub(sf.pop(), variabili.get(c)));
    }

    @Override
    public void duplicazioneVariabile(char c) throws  InvalidInputException,StackFullException {
       if(!variabili.containsKey(c))
            throw new InvalidVariableException ();
       else if (sf.getSize()==sf.getMaxSize())
           throw new StackFullException();
  
       sf.push(variabili.get(c));
    }

    @Override
    public void assegnaVaribile(char c) throws StackUnderflowException{
            if(sf.getSize()==0)
                throw new StackUnderflowException();
            if(variabili.containsKey(c))
                variabili.replace(c, sf.pop());
            else
                variabili.put(c, sf.pop());
    }
    
}
