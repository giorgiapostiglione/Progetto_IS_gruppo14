/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculator.model;

import calculator.exception.StackFullException;
import calculator.exception.StackUnderflowException;
import java.util.Stack;

/**
 *
 * @author Carlo Marna
 */
public class StackFinito {
    private Stack <Complex> memoria;
    private final int maxSize = 50;
    StackFinito(){
        memoria = new Stack <Complex>();
    }

    public void push(Complex element) throws StackFullException{
        if(memoria.size() < maxSize)
            memoria.add(element);
        else
            throw new StackFullException();
    }
    
   public Complex  pop() throws StackUnderflowException{
     if(!memoria.empty())
           return memoria.pop();
           
        else
            throw new StackUnderflowException();
    }
   
   public int getSize(){
       return memoria.size();
   }

    public int getMaxSize() {
        return maxSize;
    }

   public Complex viewElement(int index){
       return memoria.get(index);
   }
   
   public Complex viewSecondLastElement() throws StackUnderflowException{
       return memoria.get(memoria.size()-2);
   }
    public String stampaDodiceElementi() {
        StringBuffer sb = new StringBuffer();
        int count = 0;
        for(int i = memoria.size()-1; i >=0 ; i--){
            if(count<12){
                sb.append(memoria.get(i).toString());
                count++;
                
            }
        }
        return  sb.toString() ; 
    }
    
    
}
